<?Php
$top_menu=" <a href=index.php>Home</a> | <a href=pdo-records.php>List of records</a> | <a href=pdo-fetch.php>Fetch</a>  | <a href=pdo-insert.php>Add Record</a> | <a href=pdo-update.php>Update</a> | 
 <a href=pdo-delete.php>Delete</a> | <a href=pdo-drop.php>Drop</a> | <a href=pdo-rowcount.php>Rowcount</a> | <a href=pdo-execute-dump.php>Reinitialize table and data</a>
";
echo "<div id='menu'>$top_menu</div>";
?>