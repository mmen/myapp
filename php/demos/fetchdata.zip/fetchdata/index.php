<?php
include_once("function.php");
$fetchdata=new DB_con(); 

 ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta charset="utf-8">
		<title>PHP GURUKUL | DEMO</title>
		<meta name="generator" content="Bootply" />
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<!--[if lt IE 9]>
			<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		<link href="css/styles.css" rel="stylesheet">
	</head>
	<body>
<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
	<div class="navbar-header">
        <a class="navbar-brand" rel="home" href="#">Home</a>
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
		<span class="sr-only">Toggle navigation</span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		</button>
	</div>
	<div class="collapse navbar-collapse">
		<ul class="nav navbar-nav">
			<li><a href="#">Link</a></li>
			<li><a href="#">Link</a></li>
			<li><a href="#">Link</a></li>
			<li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Dropdown <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="#">Link </a></li>
                <li><a href="#">Link</a></li>
                <li class="divider"></li>
                <li><a href="#">Link</a></li>
                <li class="divider"></li>
                <li><a href="#">Link</a></li>
              </ul>
            </li>
		</ul>
		
	</div>
</nav>

<div class="container-fluid">
  

      
     
 <!--/left-->
  
  <!--center-->
  <div class="col-sm-8">
    <div class="row">
      <div class="col-xs-12">
        <h3>Fetch Data From Database Using OOPS Concept</h3>
		<h4>Insert the data in the previous post(How to insert data) and see the result here</h4>
		<hr >

     <table width="100%"  border="0" >
  <tr>
    <th width="9%" height="42" scope="col" >S no.</th>
    <th width="13%" scope="col">Name</th>
    <th width="11%" scope="col">Email</th>
    <th width="11%" scope="col">Contact no</th>
    <th width="11%" scope="col">Gender</th>
    <th width="13%" scope="col">Education</th>
    <th width="13%" scope="col">Address</th>
    <th width="19%" scope="col">PostingDate</th>
  </tr>
  <?php
  $sql=$fetchdata->fetchdata();
  $cnt=1;
  while($row=mysqli_fetch_array($sql))
  {
  ?>
  <tr>
      <td height="29"><?php echo $cnt;?></td>
    <td><?php echo $row['name'];?></td>
    <td><?php echo $row['email'];?></td>
    <td><?php echo $row['contactno'];?></td>
    <td><?php echo $row['gender'];?></td>
    <td><?php echo $row['education'];?></td>
    <td><?php echo $row['addrss'];?></td>
    <td><?php echo $row['posting_date'];?></td>

  </tr>
  <?php $cnt=$cnt+1;} ?>
</table>


   
 
      </div>
    </div>
        
   
  </div><!--/center-->

<!--/right-->
  <hr>
</div><!--/container-fluid-->
	<!-- script references -->
		<script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
	</body>
</html>