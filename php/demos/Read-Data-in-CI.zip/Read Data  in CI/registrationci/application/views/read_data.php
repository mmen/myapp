<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <!-- This file has been downloaded from Bootsnipp.com. Enjoy! -->
    <title>How to fetch  data from datbase in CodeIgniter </title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
<?php echo link_tag('http://netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css');?>
    <style type="text/css">
        .table-bordered {
border: 1px solid #dddddd;
border-collapse: separate;
border-left: 0;
-webkit-border-radius: 4px;
-moz-border-radius: 4px;
border-radius: 4px;
}

.table {
width: 100%;
margin-bottom: 20px;
background-color: transparent;
border-collapse: collapse;
border-spacing: 0;
display: table;
}

.widget.widget-table .table {
margin-bottom: 0;
border: none;
}

.widget.widget-table .widget-content {
padding: 0;
}

.widget .widget-header + .widget-content {
border-top: none;
-webkit-border-top-left-radius: 0;
-webkit-border-top-right-radius: 0;
-moz-border-radius-topleft: 0;
-moz-border-radius-topright: 0;
border-top-left-radius: 0;
border-top-right-radius: 0;
}

.widget .widget-content {
padding: 20px 15px 15px;
background: #FFF;
border: 1px solid #D5D5D5;
-moz-border-radius: 5px;
-webkit-border-radius: 5px;
border-radius: 5px;
}

.widget .widget-header {
position: relative;
height: 40px;
line-height: 40px;
background: #E9E9E9;
background: -moz-linear-gradient(top, #fafafa 0%, #e9e9e9 100%);
background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #fafafa), color-stop(100%, #e9e9e9));
background: -webkit-linear-gradient(top, #fafafa 0%, #e9e9e9 100%);
background: -o-linear-gradient(top, #fafafa 0%, #e9e9e9 100%);
background: -ms-linear-gradient(top, #fafafa 0%, #e9e9e9 100%);
background: linear-gradient(top, #fafafa 0%, #e9e9e9 100%);
text-shadow: 0 1px 0 #fff;
border-radius: 5px 5px 0 0;
box-shadow: 0 2px 5px rgba(0,0,0,0.1),inset 0 1px 0 white,inset 0 -1px 0 rgba(255,255,255,0.7);
border-bottom: 1px solid #bababa;
filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#FAFAFA', endColorstr='#E9E9E9');
-ms-filter: "progid:DXImageTransform.Microsoft.gradient(startColorstr='#FAFAFA', endColorstr='#E9E9E9')";
border: 1px solid #D5D5D5;
-webkit-border-top-left-radius: 4px;
-webkit-border-top-right-radius: 4px;
-moz-border-radius-topleft: 4px;
-moz-border-radius-topright: 4px;
border-top-left-radius: 4px;
border-top-right-radius: 4px;
-webkit-background-clip: padding-box;
}

thead {
display: table-header-group;
vertical-align: middle;
border-color: inherit;
}

.widget .widget-header h3 {
top: 2px;
position: relative;
left: 10px;
display: inline-block;
margin-right: 3em;
font-size: 14px;
font-weight: 600;
color: #555;
line-height: 18px;
text-shadow: 1px 1px 2px rgba(255, 255, 255, 0.5);
}

.widget .widget-header [class^="icon-"], .widget .widget-header [class*=" icon-"] {
display: inline-block;
margin-left: 13px;
margin-right: -2px;
font-size: 16px;
color: #555;
vertical-align: middle;
}
    </style>
    <script src="<?php //echo base_url('http://code.jquery.com/jquery-1.11.1.min.js'); ?>"></script>
    <script src="<?php //echo base_url('http://netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js'); ?>"></script>
</head>
<body>
<div class="span12" align="center" style="margin-top: 2%">   
<div class="widget stacked widget-table action-table">
    				
				<div class="widget-header">
					<i class="icon-th-list"></i>
					<h3>How to fetch data in CodeIgniter 
						<a href="<?php echo site_url('Registration'); ?>" style="color:red; font-size: 20px;">(Insert Data) </a></h3>
				</div> <!-- /widget-header -->
				
				<div class="widget-content" >
					
					<table class="table table-responsive">
						<thead>
							<tr>
								<th>#</th>
								<th>Name</th>
								<th>Email id</th>
								<th> Mobile Number</th>
								<th> Gender</th>
								<th> Address</th>
								<th> Terms and Conditions</th>
								<th>Posting date</th>
							</tr>
						</thead>
						<tbody>
							

										
<?php
if(count($result)) {
$cnt=1;	
foreach ($result as $row){

?>


<tr>
<td><?php echo htmlentities($cnt);?></td>
<td><?php echo htmlentities($row->fullName)?></td>
<td><?php echo htmlentities($row->emailId)?></td>
<td><?php echo htmlentities($row->mobileNumber)?></td>
<td><?php echo htmlentities($row->gender)?></td>
<td><?php echo htmlentities($row->address)?></td>
<td><?php echo htmlentities($row->address)?></td>
<td><?php echo htmlentities($row->postingDate)?></td>

							</tr>
<?php 
$cnt++;
}
}else { ?>

<tr>
<td colspan="7">No Record found</td>
</tr>
<?php
}
?>								
							</tbody>
						</table>
					
				</div> <!-- /widget-content -->
			
			</div> <!-- /widget -->
            </div>
<script type="text/javascript">

</script>
</body>
</html>
