<?php

Class Read_data extends CI_Controller{
	
public function index(){

$this->load->model('Read_data_Model');
$results=$this->Read_data_Model->readdata();
$this->load->view('read_data',['result'=>$results]);

}

}