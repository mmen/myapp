<?php
class Signupform extends CI_Controller {
public function __construct() {
parent::__construct();
       $this->load->library('form_validation');
}

public function index(){
$this->form_validation->set_rules('fullname','Full Name','required|alpha');
$this->form_validation->set_rules('email','Email id','required|valid_email');
$this->form_validation->set_rules('phonenumber','Phone Number','required|numeric|exact_length[10]');
$this->form_validation->
set_rules('username','User name','required|alpha_numeric|min_length[6]|max_length[12]|is_unique[tblusers.username]');
$this->form_validation->set_rules('password','Password','required|min_length[6]');
$this->form_validation->set_rules('cpassword','Confirm Password','required|min_length[6]|matches[password]');
if($this->form_validation->run()){
	echo "Form submitted";
}
else{
	$this->load->view("signup_form");
}
}
}