<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$dbname = "test";
$mysqli = new mysqli($host, $dbuser, $dbpass, $dbname);
?>