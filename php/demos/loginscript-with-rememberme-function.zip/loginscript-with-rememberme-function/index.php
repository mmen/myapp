<?php
session_start();
include('config.php');
if(isset($_POST["login"])) 
{
$username=$_POST['username'];
$password=md5($_POST['password']);
$sql = "Select * from tbluser where userName ='$username' and userPassword ='$password'";
	$result = mysqli_query($conn,$sql);
	$row = mysqli_fetch_array($result);
	if($row) {
			$_SESSION["userid"]= $row["id"];
			
			if(!empty($_POST["remember"])) {
				setcookie ("user_login",$_POST["username"],time()+ (10 * 365 * 24 * 60 * 60));
				setcookie ("userpassword",$_POST["password"],time()+ (10 * 365 * 24 * 60 * 60));
			} else {
				if(isset($_COOKIE["user_login"])) {
					setcookie ("user_login","");
				}
				if(isset($_COOKIE["userpassword"])) {
					setcookie ("userpassword","");
				}
			}
	header('location:welcome.php');
	} else {
		$message = "Invalid Login";
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>PHP Login with remember me Function</title>
	<style>
	#login {

		padding: 20px 60px;
		background: #25AAE1;
		color: #555;
		display: inline-block;		
		border-radius: 4px;
	}
	.field-group {
		margin-top:15px;
	}
	.input-field {
		padding: 8px;
		width: 200px;
		border: #A3C3E7 1px solid;
		border-radius: 4px;
	}
	.form-submit-button {
		background: #EC008C;
		border: 0;
		padding: 8px 20px;
		border-radius: 4px;
		color: #FFF;
		text-transform: uppercase;
	}
	.error-message {
		text-align:center;
		color:#FF0000;
	}
	</style>

</head>
<body>
<div align="center">

<form action="" method="post" id="login">
	<div class="error-message"><?php if(isset($message)) { echo $message; } ?></div>
	<h4> PHP login with remember me function</h4>	
	<div class="field-group">
		<div><label for="login">Username</label></div>
		<div>

<input name="username" type="text" value="<?php if(isset($_COOKIE["user_login"])) { echo $_COOKIE["user_login"]; } ?>" class="input-field">
	</div>
	<div class="field-group">
		<div><label for="password">Password</label></div>
		<div><input name="password" type="password" value="<?php if(isset($_COOKIE["userpassword"])) { echo $_COOKIE["userpassword"]; } ?>" class="input-field"> 
	</div>
	<div class="field-group">
		<div><input type="checkbox" name="remember" id="remember" <?php if(isset($_COOKIE["user_login"])) { ?> checked <?php } ?> />
		<label for="remember-me">Remember me</label>
	</div>
	<div class="field-group">
		<div><input type="submit" name="login" value="Login" class="form-submit-button"></span></div>
	</div>       
</form>
</div>


</body>
</html>