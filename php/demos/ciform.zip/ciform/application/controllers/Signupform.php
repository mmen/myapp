<?php

class Signupform extends CI_Controller {
public function __construct() {
parent::__construct();
}


public function index(){

// loadin from view
	$this->load->view("signup_form");
}
}