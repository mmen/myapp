-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2018 at 01:50 PM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `storeprocedure`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `checkavailbilty` (IN `email` VARCHAR(255))  NO SQL
SELECT EmailId FROM tblregistration  WHERE EmailId=email$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `login` (IN `useremail` VARCHAR(255), IN `password` VARCHAR(255))  NO SQL
SELECT EmailId,Password from  tblregistration where EmailId=useremail and Password=password$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `registration` (IN `fname` VARCHAR(200), IN `emailid` VARCHAR(200), IN `password` VARCHAR(255))  NO SQL
insert into tblregistration(FullName,EmailId,Password) VALUES(fname,emailid,password)$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tblregistration`
--

CREATE TABLE `tblregistration` (
  `id` int(11) NOT NULL,
  `FullName` varchar(200) NOT NULL,
  `EmailId` varchar(200) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `RegDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblregistration`
--

INSERT INTO `tblregistration` (`id`, `FullName`, `EmailId`, `Password`, `RegDate`) VALUES
(1, 'Anuj kumar', 'anuj@gmail.com', 'Test@123', '2018-05-14 04:43:50'),
(2, 'fsfsd', 'sdfsdfs', 'd6e9c56d7f078d298ed4695d899effbe', '2018-05-14 05:26:08'),
(3, 'fsfsd', 'sdfsdfs', 'd6e9c56d7f078d298ed4695d899effbe', '2018-05-14 05:28:45'),
(4, 'ihi', 'iyuii@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2018-05-14 05:29:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblregistration`
--
ALTER TABLE `tblregistration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblregistration`
--
ALTER TABLE `tblregistration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
