<?php
include('config.php');
if(isset($_POST['register']))
{
 $fname=$_POST['fname'];
 $email=$_POST['email'];
 $password=md5($_POST['password']);
$query=mysqli_query($con,"call registration('$fname','$email','$password')");

if($query)
{
echo "<script>alert('Registration Successfull');</script>";
}
else
{
echo "<script>alert('Something went wrong. Please try again.');</script>";
}

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <!-- This file has been downloaded from Bootsnipp.com. Enjoy! -->
    <title>Registration using Store Procedure</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="http://netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet">
    <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
<script>
function checkAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "check_availability.php",
data:'emailid='+$("#email").val(),
type: "POST",
success:function(data){
$("#user-availability-status").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}
</script>

</head>
<body>
<form class="form-horizontal"  method="post">
  <fieldset>
    <div id="legend">
      <legend align="center" style="font-size: 35px;">Register</legend>
    </div>
    <div class="control-group">
      <!-- Fullname -->
      <label class="control-label"  for="fname">Full Name</label>
      <div class="controls">
        <input type="text" id="name" name="fname" placeholder="" class="input-xlarge" required>

      </div>
    </div>
 
    <div class="control-group">
      <!-- E-mail -->
      <label class="control-label" for="email">E-mail</label>
      <div class="controls">
        <input type="email" id="email" name="email" placeholder="" class="input-xlarge" onBlur="checkAvailability()"  required>
 <span id="user-availability-status" style="font-size:12px;"></span> 
      </div>
    </div>
 
    <div class="control-group">
      <!-- Password-->
      <label class="control-label" for="password">Password</label>
      <div class="controls">
        <input type="password" id="password" name="password" placeholder="" class="input-xlarge" required>
      </div>
    </div>
 

 
    <div class="control-group">
      <!-- Button -->
      <div class="controls">
        <input  class="btn btn-success" id="submit" type="submit" value='register' name="register">
      </div>
    </div>
 


    <div class="control-group">
      <div class="controls">
   <p class="message">Already registered. <a href="login.php">login here</a></p>
      </div>

    </div>

  </fieldset>
</form>

</body>
</html>
