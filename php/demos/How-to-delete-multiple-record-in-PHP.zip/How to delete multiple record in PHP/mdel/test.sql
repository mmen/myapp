-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 22, 2019 at 12:45 PM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `id` int(11) NOT NULL,
  `FullName` varchar(140) DEFAULT NULL,
  `Education` varchar(120) DEFAULT NULL,
  `postingDate` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`id`, `FullName`, `Education`, `postingDate`) VALUES
(1, 'Anuj K1', 'B.Tech', 2018),
(2, 'Anuj K2', 'B.Tech', 2018),
(3, 'Anuj K3', 'B.Tech', 2018),
(4, 'Anuj K4', 'B.Tech', 2018),
(5, 'Anuj K5', 'B.Tech', 2018),
(6, 'Anuj K6', 'B.Tech', 2018),
(7, 'Anuj K7', 'B.Tech', 2018),
(8, 'Anuj K8', 'B.Tech', 2018),
(9, 'Anuj K9', 'B.Tech', 2018),
(10, 'Anuj K10', 'B.Tech', 2018),
(11, 'Anuj K11', 'B.Tech', 2018),
(12, 'Anuj K12', 'B.Tech', 2018),
(13, 'Anuj K13', 'B.Tech', 2018),
(14, 'Anuj K14', 'B.Tech', 2018),
(15, 'Anuj K15', 'B.Tech', 2018),
(16, 'Anuj K16', 'B.Tech', 2018),
(17, 'Anuj K17', 'B.Tech', 2018),
(18, 'Anuj K18', 'B.Tech', 2018),
(19, 'Anuj K19', 'B.Tech', 2018),
(20, 'Anuj K20', 'B.Tech', 2018),
(21, 'Anuj K21', 'B.Tech', 2019),
(22, 'Anuj K22', 'B.Tech', 2019),
(23, 'Anuj K23', 'B.Tech', 2019),
(24, 'Anuj K24', 'B.Tech', 2019),
(25, 'Anuj K25', 'B.Tech', 2019),
(26, 'Anuj K26', 'B.Tech', 2019),
(27, 'Anuj K27', 'B.Tech', 2019),
(28, 'Anuj K28', 'B.Tech', 2019),
(29, 'Anuj K29', 'B.Tech', 2019),
(30, 'Anuj K30', 'B.Tech', 2019),
(31, 'Anuj K31', 'B.Tech', 2019),
(32, 'Anuj K32', 'B.Tech', 2019),
(33, 'Anuj K33', 'B.Tech', 2019),
(34, 'Anuj K34', 'B.Tech', 2019),
(35, 'Anuj K35', 'B.Tech', 2019),
(36, 'Anuj K36', 'B.Tech', 2019),
(37, 'Anuj K37', 'B.Tech', 2019),
(38, 'Anuj K38', 'B.Tech', 2019),
(39, 'Anuj K39', 'B.Tech', 2019),
(40, 'Anuj K40', 'B.Tech', 2019),
(41, 'Anuj K41', 'B.Tech', 2019),
(42, 'Anuj K42', 'B.Tech', 2019),
(43, 'Anuj K43', 'B.Tech', 2019),
(44, 'Anuj K44', 'B.Tech', 2019),
(45, 'Anuj K45', 'B.Tech', 2019),
(46, 'Anuj K46', 'B.Tech', 2019),
(47, 'Anuj K47', 'B.Tech', 2019),
(48, 'Anuj K48', 'B.Tech', 2019),
(49, 'Anuj K49', 'B.Tech', 2019),
(50, 'Anuj K50', 'B.Tech', 2019);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
