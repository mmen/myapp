<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <!-- This file has been downloaded from Bootsnipp.com. Enjoy! -->
    <title>CodeIgniter Form Validation Tutorial</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="http://netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">

    <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
</head>
<body>
<section id="login">
    <div class="container">
    	<div class="row">
    	    <div class="col-xs-12">
        	    <div class="form-wrap">
                <h1>Signup Form</h1>


<?php echo form_open('signupform',['name'=>'signup']);?>

<div class="form-group">
<?php echo form_input(['name'=>'fullname','id'=>'fullname','placeholder'=>'Enter your full name','class'=>'form-control']);?>
<?php echo form_error('fullname','<div style="color:red">', '</div>'); ?>
</div>

<div class="form-group">
<?php echo form_input(['name'=>'email','id'=>'email','placeholder'=>'Enter your valid email','class'=>'form-control']);?>
<?php echo form_error('email','<div style="color:red">', '</div>'); ?>
</div>

<div class="form-group">
<?php echo form_input(['name'=>'phonenumber','id'=>'phonenumber','placeholder'=>'Enter your 10 digit mobile number','class'=>'form-control']);?>
<?php echo form_error('phonenumber','<div style="color:red">', '</div>'); ?>
</div>


<div class="form-group">
<?php echo form_input(['name'=>'username','id'=>'username','placeholder'=>'Enter your username','class'=>'form-control']);?>
<?php echo form_error('username','<div style="color:red">', '</div>'); ?>
</div>

<div class="form-group">
<?php echo form_password(['name'=>'password','id'=>'password','placeholder'=>'Enter your password','class'=>'form-control']);?>
<?php echo form_error('password','<div style="color:red">', '</div>'); ?>
</div>

<div class="form-group">
<?php echo form_password(['name'=>'cpassword','id'=>'cpassword','placeholder'=>'Confirm your password','class'=>'form-control']);?>
<?php echo form_error('cpassword','<div style="color:red">', '</div>'); ?>
</div>

<div class="form-group">
<?php echo form_textarea(['name'=>'address','rows'=>'5','cols'=>'10','id'=>'address','class'=>'form-control','placeholder'=>'Enter your address']);?>
</div>  
                        
<?php echo form_submit(['name'=>'submit','value'=>'Submit','class'=>'btn btn-custom btn-lg btn-block']);?>
                <?php echo form_close();?>
               
        	    </div>
    		</div> <!-- /.col-xs-12 -->
    	</div> <!-- /.row -->
    </div> <!-- /.container -->
</section>
</body>
</html>
