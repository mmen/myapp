<?php

$config = array(
	
array(
'field' => 'fullname',
'label' => 'Full Name',
'rules' => 'required'
),
array(
'field' => 'email',
'label' => 'Email Address',
'rules' => 'required|valid_email'
),
array(
'field' => 'phonenumber',
'label' => 'Phone Number',
'rules' => 'required|numeric|exact_length[10]'
),

array(
'field' => 'username',
'label' => 'User name',
'rules' => 'required|alpha_numeric|min_length[6]|max_length[12]|is_unique[tblusers.username]'
),

array(
'field' => 'password',
'label' => 'Password',
'rules' => 'required|min_length[6]'
),

array(
'field' => 'cpassword',
'label' => 'Confirm Password',
'rules' => 'required|min_length[6]|matches[password]'
)

);