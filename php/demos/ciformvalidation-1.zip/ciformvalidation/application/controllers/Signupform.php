<?php
class Signupform extends CI_Controller {
public function __construct() {
parent::__construct();
       $this->load->library('form_validation');
}

public function index(){

if($this->form_validation->run()){
	echo "Form submitted";
}
else{
	$this->load->view("signup_form");
}
}
}